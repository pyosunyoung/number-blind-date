import "./App.css";
import AppRouter from "./routes/AppRouter";

// npm install axios 

function App() {
  return (
    <div>
      <AppRouter />
    </div>
  );
}

export default App;
