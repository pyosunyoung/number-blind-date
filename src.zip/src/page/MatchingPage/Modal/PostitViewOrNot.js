import React from 'react'

const PostitViewOrNot = () => {
  return (
    <div>
      <div>모달 작업</div> 
    </div>
  )
}

export default PostitViewOrNot
