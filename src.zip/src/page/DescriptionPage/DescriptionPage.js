import React from 'react'

const DescriptionPage = () => {
  return (
    <div>
      어플 설명서 페이지
    </div>
  )
}

export default DescriptionPage
