import React from 'react'

const AIMatchingPage = () => {
  return (
    <div>
      AIMatchingPage
    </div>
  )
}

export default AIMatchingPage
